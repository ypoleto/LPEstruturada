#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>
#include <windows.h>

struct tcarro
{
    char placa[9];
    char dono[71];
    char modelo[21];
    char horaEntrada[10];
    char horaLavagem[10];
};
typedef struct tcarro Carro;


void flush_in()
{
    int ch;
    while ((ch = fgetc(stdin)) != EOF && ch != '\n')
    {
    }
}


int menu()
{
    int opcao;
    char buffer[10];

    printf("\n\033[34mInforme a opção desejada de acordo com o menu:\033[0m");
    printf("\n|--------------------MENU--------------------|\n|                                            |\n|1- Adicionar carro na fila                  |\n|2- Lavar carro                              |\n|3- Consultar fila de lavagem                |\n|4- Consultar fila de espera                 |\n|5- Encerrar                                 |\n|____________________________________________|\n\n--> ");
    fgets(buffer, 10, stdin);
    sscanf(buffer, "%d", &opcao);

    return opcao;
}


void cadastro(Carro *listaDeCarros, int *pos)
{
    time_t timer;
    
    struct tm *info;

    time(&timer);
    info = gmtime(&timer);
    info->tm_hour = info->tm_hour -3;
    

    Carro *carro = (Carro *)malloc(sizeof(Carro));
    printf("Digite a placa com 7 digitos:  ");
    fgets(carro->placa, 9, stdin);
    carro->placa[strcspn(carro->placa, "\n")] = 0;

    printf("Digite o nome do dono: ");
    fgets(carro->dono, 80, stdin);
    carro->dono[strcspn(carro->dono, "\n")] = 0;

    printf("Digite o nome do modelo: ");
    fgets(carro->modelo, 50, stdin);
    carro->modelo[strcspn(carro->modelo, "\n")] = 0;

    strftime(carro->horaEntrada, 10, "%H:%M", info);


    printf("\n\033[32;1;4mCarro adicionado com sucesso:\033[0m\n\033[32mPlaca ->   %s\nDono ->    %s\nModelo ->  %s\nHora Entrada -> %s\n\033[0m", carro->placa, carro->dono, carro->modelo, carro->horaEntrada);
    
    listaDeCarros[*pos] = *carro;
    (*pos)++;
}


void lavagem(Carro *listaNormal, int tamListaNormal, Carro *listaEspera, Carro *carrosLavados, int posicaoCarrosLavados)
{
    int i;
    time_t timer;
    
    struct tm *info;

    time(&timer);
    info = gmtime(&timer);
    info->tm_hour = info->tm_hour -3;

    strftime(listaNormal->horaLavagem, 10, "%H:%M", info);
    


    carrosLavados[posicaoCarrosLavados] = listaNormal[0];
    
//mover lista normal 1 2 3 4 | 1 2 3
    for (i = 0; i < tamListaNormal - 1; i++)
    {
        listaNormal[i] = listaNormal[i + 1];
    }

    //mover lista de espera
    listaNormal[tamListaNormal - 1] = listaEspera[0];
    listaEspera[0] = listaEspera[1];
    listaEspera[1] = listaEspera[2];
}


void consultalavagem(Carro *listaNormal, int posicaoListaNormal)
{
    int i;
    if (posicaoListaNormal == 0)
    {
        printf("\n\033[31mNenhum carro na lista normal.\033[0m\n");
    }
    else
    {
        printf("\033[32m\nLista de carros pela placa -> \033[0m");
        for (i = 0; i < posicaoListaNormal; i++)
        {
            printf(" %s |", listaNormal[i].placa);
        }
        printf("\n");
    }
}


void consultaespera(Carro *listaEspera, int posicaoListaEspera)
{

    int i;
    
    if (posicaoListaEspera == 0)
    {
        printf("\n\033[31mNenhum carro na lista de espera.\033[0m\n");
    }
    else
    {
        printf("\033[32m\nLista de carros pela placa -> \033[0m");
        for (i = 0; i < posicaoListaEspera; i++)
        {
            printf("%s | ", listaEspera[i].placa);
        }
        printf("\n");
    }
}


void criarelatorio(Carro *carrosLavados, int posicaoCarrosLavados)
{
    int i;
    FILE *relatorio = NULL;
    relatorio = fopen("relatorio.txt", "w");
    if (relatorio == NULL)
        printf("Erro ao abrir");

    else
    {
        fprintf(relatorio, "_____________RELATÓRIO DE LAVAGENS______________\n");
        fprintf(relatorio, "              ___________\n             //   |||   \\\\\n          __//____|||____\\\\____\n         | _|      |       _  ||\n         |/ \\______|______/ \\_||\n__________\\_/_____________\\_/___________________\n\n\n");


        if (posicaoCarrosLavados > 0)
        {
            for (i = 0; i < posicaoCarrosLavados; i++)
            {
                fprintf(relatorio, "┌─────────────────────Carro %d────────────────────\n│Placa:           %s\n│Nome do dono:    %s\n│Modelo do carro: %s\n│Hora de entrada: %s\n│Hora de lavagem: %s\n└────────────────────────────────────────────────\n", i + 1, carrosLavados[i].placa, carrosLavados[i].dono, carrosLavados[i].modelo, carrosLavados[i].horaEntrada, carrosLavados[i].horaLavagem);
            }
        }
        else
        {
            fprintf(relatorio, "Não há nenhum carro por aqui.");
        }

        fclose(relatorio);
    }
}


void sair(Carro *carrosLavados, int posicaoCarrosLavados)
{
    char confirma[2];

    printf("\033[31;1;4mDeseja sair? [S/N]\033[0m \n--> ");
    fgets(confirma, 2, stdin);
    flush_in();

    if ((strcmp(confirma, "S") == 0) || (strcmp(confirma, "s") == 0))
    {
        printf("\033[32mObrigada por utilizar o sistema! \nUm relatório de todas as lavagens do dia foi criado.\nVocê lavou %d carros hoje e pode conferi-los no arquivo \"relatorio.txt\".\033[0m", posicaoCarrosLavados);
        criarelatorio(carrosLavados, posicaoCarrosLavados);
        exit(0);
    }
    else if ((strcmp(confirma, "N") == 0) || (strcmp(confirma, "n") == 0))
    {
        return;
    }
    else
    {
        printf("\033[31;1Opção inválida, voltando para o menu...\n\n\033[0m");
    }
}


int main()
{
    UINT CPAGE_UTF8 = 65001;
	UINT CPAGE_DEFAULT = GetConsoleOutputCP();
	SetConsoleOutputCP(CPAGE_UTF8);


    int opcao, capacidade;
    char mudarnome[3], nome[40] = "LavaTudo", buffer[10];
    printf("\033[34mBem vindo ao Lava-Carros! Deseja mudar o nome? [S/N] \n---> \033[0m");
    scanf("%s", mudarnome);

    if ((strcmp(mudarnome, "S") == 0) || (strcmp(mudarnome, "s") == 0)){
        flush_in();
        printf("\nDigite o novo nome do Lava-Carros:\n--> ");
        fgets(nome, 40, stdin);
        nome[strcspn(nome, "\n")] = 0;
    }
    printf("\n\033[34mBem vindo ao Lava-Carros %s! Lembre-se: O limite diário de lavagens é de 20 carros.\nPara iniciar, digite a capacidade de carros na garagem.\n>>>> \033[0m", nome);
    scanf("%d", &capacidade);
    flush_in();
    Carro listaNormal[capacidade];
    Carro listaEspera[3];

    Carro carrosLavados[20];

    int posicaoListaNormal = 0;
    int posicaoListaEspera = 0;
    int posicaoCarrosLavados = 0;

    do
    {
        switch (opcao = menu())
        {
        case 1: //Adiciona

            if (posicaoListaEspera == 3)
            { // fila de espera lotada
                printf("\033[31;1m\nO Lava-Carros está lotado!\033[0m\n");
            }
            else
            { // cadastra na fila atual
                if (posicaoListaNormal == capacidade)
                { // lista normal esta lotada
                    // cadastra lista de espera
                    cadastro(listaEspera, &posicaoListaEspera);
                }
                else
                {
                    // lista normal tem vagas
                    cadastro(listaNormal, &posicaoListaNormal);
                }
            }
            break;

        case 2: //Lava
            lavagem(listaNormal, capacidade, listaEspera, carrosLavados, posicaoCarrosLavados);

            if (posicaoListaNormal == 0)
            {
                printf("\033[31;1m\nTodos os carros já foram lavados!\n\033[0m");
                posicaoCarrosLavados--;
            }

            if (posicaoListaEspera == 0)
            { // se a lista de espera estava vazia, lavamos da lista normal, logo temos que arrumar a posicao atual, que é a proxima posicao onde vamos inserir um carro
                if (posicaoListaNormal != 0)
                {
                    printf("\n\033[32mCarro com placa \"%s\" lavado com sucesso!\n\033[0m", carrosLavados[posicaoCarrosLavados].placa);
                    posicaoListaNormal--;
                    
                }
            }

            if (posicaoListaEspera != 0)
            { // se a lista de espera nao estava vazia, movimentamos ela, logo temos que arrumar a posicao atual, que é a proxima posicao onde vamos inserir um carro
                
                printf("\n\033[32mCarro com placa \"%s\" lavado com sucesso!\n\033[0m", carrosLavados[posicaoCarrosLavados].placa);
                posicaoListaEspera--;
            }

            if (posicaoCarrosLavados < 20)
            {

                posicaoCarrosLavados++;
            }
            else
            {
                printf("\033[31;1Limite de lavagens diárias atingida!\033");
            }

            break;

        case 3:
            consultalavagem(listaNormal, posicaoListaNormal);

            break;

        case 4:
            consultaespera(listaEspera, posicaoListaEspera);
            break;

        case 5:
            sair(carrosLavados, posicaoCarrosLavados);
            opcao = -1;
            break;

        default:
            printf("\033[31;1m\nOpção invalida.\n\033[0m");
            getchar();
            scanf("c\n");
            flush_in();
        }
    } while (opcao != 5);
}
